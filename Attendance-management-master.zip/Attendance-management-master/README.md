# Attendance-management

This project contains 2 applications one for faculties or teachers at any educational Institution and the other for students. Faculties after logged in using the subject name 
and its unique password can generate random code which is said to the students of that class, Students can login using their roll number and their password and enter the code 
said by the faculty to avail attendance for that day. After all the students gave attendance, faculty can disable the code. Faculties can also view the attendance on monthly basis.
