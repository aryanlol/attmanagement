Update Subject details by changing the values of each subject name child.

Update Student details by changing the values of each rollnumber child, Please maintain the key as roll number of the student.

This json file can be imported to any firebase realtime database.

